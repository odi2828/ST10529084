# Sweet Crumbs Bakery Website

## Student Information

**Student Name:** ODIRILE MODISE
**Student Number:** ST10529084  
**Programme:** Diploma in Information Technology in Network Management  
**Module:** Web Development  
**Project:** Sweet Crumbs Bakery Website  

---

## Project Overview

Sweet Crumbs Bakery is a fictional South African bakery created for the
website development project. The website is designed to provide customers
with information about the bakery, its products, locations and contact
details.

The website will provide a simple and accessible online presence for the
bakery and allow customers to view products and submit enquiries.

---

## Website Goals and Objectives

The main goals of the Sweet Crumbs Bakery website are to:

- Provide the bakery with an online presence.
- Display the bakery's products.
- Provide information about the organisation.
- Allow customers to submit product enquiries.
- Provide contact information and business locations.
- Make important information easy to find through clear navigation.

---

## Key Features and Functionality

The website consists of five main pages:

1. Home
2. About
3. Products
4. Enquiry
5. Contact

The website includes:

- Navigation between all pages.
- Product information.
- Product images.
- An enquiry form.
- A contact form.
- Business locations.
- Operating hours.
- Contact information.
- An embedded map.

---

## Timeline and Milestones

### Part 1

- Select target organisation.
- Develop website project proposal.
- Conduct content research.
- Source website assets.
- Develop sitemap.
- Create website file and folder structure.
- Create HTML pages.
- Add basic website content.
- Implement navigation.
- Test HTML pages.
- Create GitHub repository.

### Part 2

CSS styling and responsive design will be completed during the second
phase of the project.

### Part 3

JavaScript, form functionality and search engine optimisation will be
implemented during the final phase of the project.

---

## Part 1 Details

Part 1 focuses on building the foundation of the Sweet Crumbs Bakery
website.

The website structure was created using HTML and includes five pages:

- `index.html`
- `about.html`
- `products.html`
- `enquiry.html`
- `contact.html`

The website also contains folders for CSS, JavaScript and images.

---

## Sitemap

```text
Sweet Crumbs Bakery
│
├── Home
│   └── index.html
│
├── About
│   └── about.html
│
├── Products
│   └── products.html
│
├── Enquiry
│   └── enquiry.html
│
└── Contact
    └── contact.html
     
## part2 changelog
Updated the website structure and presentation across all pages.
Added and improved product sections for cupcakes, brownies, cookies, and dessert boxes.
Improved the product layout to make the products easier to view and compare.
Added responsive image attributes to product images using srcset and sizes.
Improved the website's responsiveness for tablet and mobile screen sizes.
Adjusted heading sizes and content spacing for different screen sizes.
Improved the navigation layout on smaller screens.
Adjusted image sizes on smaller screens to improve the viewing experience.
Updated the About page content and presentation.
Updated the Contact page with the bakery's Johannesburg and Pretoria location information, contact details, and operating information.
Updated the Enquiry page to allow customers to submit enquiries about bakery products and services.
Improved consistency of the product and content sections throughout the website.
Maintained descriptive alternative text for images to improve accessibility.
Tested the website at different screen sizes to ensure that content remains usable on desktop, tablet, and mobile devices.
Part 2 Improvements

Part 2 focused on improving the existing website rather than creating a completely new website. The original content and page structure were retained while additional improvements were made to product presentation, responsiveness, accessibility, and the overall user experience.